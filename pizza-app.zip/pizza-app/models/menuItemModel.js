var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var menuItemData = new Schema({

    title:{
        type: String
    },
    price:{
        type: Number
    },
    inStock:{
        type: Number
    },
    desc:{
        type: String
    },
    photo:{
        type: String
    },
    type:{
        type: String
    },
    createdAt: Date,
    updatedAt: Date
});

//convert the password to hash before inserting into db
menuItemData.pre('save', function(next) {
     // get the current date
     var currentDate = new Date().toISOString();

     // if created_at doesn't exist, add to that field
     if (!this.createdAt)
         this.createdAt = currentDate;
 
     next();
});

var menuItemsModel = mongoose.model('menuItems', menuItemData, 'menuItems');
module.exports = menuItemsModel;
