var mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var bcrypt = require('bcrypt');

var loginData = new Schema({
    user_control: String,
    email: {
        type: String,
        unique: true,
        required: true,
        trim: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    address: {
        type: String,
        required: true,
        trim: true
    },
    password: {
        type: String,
    },
    phone: {
        type: Number
    },
    IsAdmin: {
        type: Number,
        default: 0
    },
    deletedStatus:{
        type: String,
        default: undefined
    }
});

//convert the password to hash before inserting into db
loginData.pre('save', function(next) {
    var user = this;
    bcrypt.hash(user.password, 10, function(err, hash) {
        if (err)
            return next(err);
        user.password = hash;
        next();
    });
});

var loginModel = mongoose.model('loginModel', loginData, 'loginModel');
module.exports = loginModel;
