var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

    ObjectId = Schema.ObjectId;

var orderDetailData = new Schema({
    userId: {
        type: ObjectId
    },
    orderId: {
        type: String
    },
    ItemArray: {
        type: Array
    },
    amount:{
        type: Number
    },
    createdAt: Date
});

//convert the password to hash before inserting into db
orderDetailData.pre('save', function(next) {
     // get the current date
     var currentDate = new Date().toISOString();

     // if created_at doesn't exist, add to that field
     if (!this.createdAt)
         this.createdAt = currentDate;
 
     next();
});

var orderModel = mongoose.model('orderDetailModel', orderDetailData, 'orderDetailModel');
module.exports = orderModel;
