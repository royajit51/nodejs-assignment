var mongoose = require('mongoose');
mongoose.Promise = Promise;

var MONGO_DB_CONNECTION_URL = `mongodb://localhost:27017/pizzaApp`; //  this is URL used only without credentials

/*DB Connect*/
function mongoConnect() {
    mongoose.connection.openUri(
        MONGO_DB_CONNECTION_URL,
        function(err) {
            if (err) {
                console.error("Error: ", err);
            }
            console.log("Connected.... Unless You See An Error The Line Before This..!!");
        });
    mongoose.set('debug', true);
}
/*DB Connect ends*/

//mongoConnect();

/*DB Connect*/
function mongoConnectOld() {
    mongoose.connection.openUri(
        MONGO_DB_CONNECTION_URL_OLD,
        function(err) {
            if (err) {
                console.error("Error: ", err);
            }
            console.log("Connected.... Unless You See An Error The Line Before This..!!");
        });
    mongoose.set('debug', true);
}
/*DB Connect ends*/

/* Drop Collection */
function dropCollection(collectionName) {
    mongoose.connection.openUri(
        MONGO_DB_CONNECTION_URL_OLD,
        function(err) {
            if (err) {
                console.error("Error: ", err);
            }
            mongoose.connection.dropCollection(collectionName, function(err){
                if (err) throw err;
                console.log("Collection " + collectionName + " deleted successfully..!!");
            });
        });
}
/* Drop Collection Ends*/

function dgsafeConnection(uri) {
    const db =  mongoose.createConnection(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });

    db.on('error', function (error) {
        console.log(`MongoDB : connection ${this.name} ${JSON.stringify(error)}`);
        db.close().catch(() => console.log(`MongoDB : failed to close connection ${this.name}`));
    });

    db.on('connected', function () {
        mongoose.set('debug', function (col, method, query, doc) {
            console.log(`MongoDB : ${this.conn.name} - ${col}.${method}(${JSON.stringify(query)},${JSON.stringify(doc)})`);
        });
        console.log(`MongoDB : Connected ${this.name}`);
    });

    db.on('disconnected', function () {
        console.log(`MongoDB : Disconnected ${this.name}`);
    });

    return db;
};

module.exports = { mongoConnect, mongoConnectOld, dropCollection, dgsafeConnection};
