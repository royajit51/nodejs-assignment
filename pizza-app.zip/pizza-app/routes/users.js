var express = require('express');
var app = express.Router();
var loginModel = require('../models/loginModel');
var menuItemModel = require('../models/menuItemModel');
var constant = require('../constants/constants');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcrypt');


app.use(express.json())

let refreshTokens = []

/* GET users listing. */
app.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

app.delete('/logout', (req, res) => {
    refreshTokens = refreshTokens.filter(token => token !== req.body.token)
    res.sendStatus(204)
})

function generateAccessToken(user) {
    return jwt.sign(user, constant.ACCESS_TOKEN_KEY, { expiresIn: '15s' })
}

app.post("/login", async (req, res) => {
    console.log("inside");
    if (Object.keys(req.body).length === 0) {
        return res.status(400).json({ message: 'All fields are mandatory' })
    } else {
        const email = req.body.email.toLowerCase();
        let password = req.body.password;

        const user = { email_id: email };
    
        const accessToken = generateAccessToken(user);
        const refreshToken = jwt.sign(user, constant.REFRESH_TOKEN_KEY);
        refreshTokens.push(refreshToken);

        loginModel.findOne({ email: email }).exec(function (err, user) {
            if (err) {
                return res.json({
                    status: 401,
                    msg: "something went wrong"
                })
            }

            if (email !== '') {
                if (user === null) {
                    return res.json({
                        status: 401,
                        msg: "User not exist"
                    })
                }
            }

            if (user === null) {
                return res.json({
                    status: 401,
                    msg: "Please enter your valid email"
                })
            }
            if (!user) return res.status(400).json("No user found");
            if (user._id !== undefined) {
                if (user.deletedStatus === 'deleted') {
                    return res.json({
                        status: 401,
                        msg: "Your account has been deactivated. Please contact Admin"
                    })
                } else {
                    bcrypt.compare(password, user.password, async function (err, resultCompare) {
                        //password matched 
                        console.log(resultCompare);
                        if (resultCompare == true) {
                            menuItemModel.find({}).exec(function (err, menu) {
                                if (err) {
                                    return res.json({
                                        status: 401,
                                        msg: "something went wrong"
                                    })
                                }
                            res.json({ accessToken: accessToken, 
                                refreshToken: refreshToken,
                                menuItems: menu
                            })
                        });
                        } else {
                            return res.json({
                                status: 401,
                                msg: "Wrong username or password"
                            })
                        }
                    })
                }
            }
        });
    }
});

app.post("/register", async (req, res) => {
    if (Object.keys(req.body).length === 0) {
        return res.status(400).json({ message: 'All fields are mandatory' })
    } else {
        let email = req.body.email.toLowerCase();

        let userData = {
            name: req.body.name,
            email: req.body.email.toLowerCase(),
            password: req.body.password,
            address: req.body.address,
            phone: req.body.phone
        };

        loginModel.find({ email: email }).exec(function (err, user) {
            if (err) {
                return res.json({
                    status: 401,
                    msg: "something went wrong"
                })
            }
            console.log(user);
            if(user.length > 0) {
                if (user.deletedStatus != 'deleted') {
                    return res.status(201).json({
                        status: 201,
                        message: "Email Already Exists"
                    });;
                } else if (user.deletedStatus === 'deleted') {
                    return res.json({
                        status: 401,
                        msg: "Your account has been deactivated. Please contact Admin"
                    })
                }
            }

            else if (user.length == 0) {

                loginModel.create(userData, function (err, status) {
                    if (err) {
                        console.log("Error: ", err);
                        throw err;
                    }
                    if (status) {
                        return res.json({
                            status: 200,
                            results: status
                        });
                    }
                });
            
            }
        });
    }
});

app.post("/editProfile", async (req, res) => {

    var id = new ObjectID(req.body._id);
    let userData = {
        _id: id,
        name: req.body.name,
        email: req.body.email.toLowerCase(),
        password: req.body.password,
        address: req.body.address,
        phone: req.body.phone
    };

    await loginModel.updateOne({
        _id: id
    }, userData, function (err, updateStatus) {
        if (err)
            return res.status(500).json(err);
        res.json(updateStatus);
    });
});

app.post("/deleteUser", function (req, res) {
    try {
        let user_id = req.body;
            loginModel.find({ _id: user_id }).exec(function (err, user) {
                if (err) {
                    return res.json({
                        status: 401,
                        msg: "something went wrong"
                    })
                }

                if (user.length > 0) {
                    loginModel.update({
                        _id: user_id
                    }, {
                        $set: {
                            "deletedStatus": "deleted"
                        }
                    }, (error, data) => {
                        if (error) {
                            console.log("Error was Occured ... ", error);
                            message = "Error Updating"
                            return res.status(201).json({
                                status: 201,
                                results: message
                            });
                        }
                        if (data) {
                            return res.status(200).json({
                                status: 200,
                                results: "User Deleted"
                            });
                        }
                    });
                }
            });

    } catch (error) {
        console.log("here", error);
        return res.json({
            status: 201,
            message: "User Not Deleted"
        })
    }
})


module.exports = app;
