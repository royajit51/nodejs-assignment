var express = require('express');
var app = express.Router();
var loginModel = require('../models/loginModel');
var menuItemModel = require('../models/menuItemModel');
var cartModel = require('../models/cartModel');
var orderModel = require('../models/orderModel');
var constant = require('../constants/constants');
var Mailgun = require('mailgun-js');
var ObjectID = require("mongodb").ObjectID;

//Your api key, from Mailgun’s Control Panel
var api_key = '2fbe671d-58d3d6cf';

const DOMAIN = 'sandbox7f9886f3393d4105b6233601bf4fbb71.mailgun.org';
const mg = Mailgun({ apiKey: api_key, domain: DOMAIN });

app.use(express.json())

app.post('/add-to-cart', function (req, res) {

    var userId = req.body.userId;
    var itemId = req.body.itemId;
    var quantity = 1;
    let updateQuery = {}

    cartModel.find({
        userId: new ObjectID(userId),
        menuItemId: itemId
    }, function (error, response) {
        if (error) {
            console.log('Error:   ', response)
            return res.status(201).json("Error Finding");
        }
        if (response) {
            if (response.length > 0) {
                let updatedQuantity = response.quantity + quantity;
                updateQuery = {
                    $set: {
                        quantity: updatedQuantity
                    }
                }

                cartModel.findByIdAndUpdate({
                    _id: response._id
                }, updateQuery, function (err, data) {
                    if (err) {
                        console.log("Error was Occurred", err)
                        return res.status(400).json({
                            message: "Error was Occurred"
                        })
                    }
                    if (data) {
                        return res.status(200).json({
                            status: 200,
                            message: "Added to Cart"
                        })
                    }
                })
            }
            else {
                cartModel.create({
                    userId: new ObjectID(userId),
                    menuItemId: itemId,
                    quantity: quantity
                }, function (error, response) {
                    if (error) {
                        console.log('Error:   ', response)
                        return res.status(201).json("Error Adding");
                    }
                    if (response) {
                        return res.json({
                            status: 200,
                            message: "Added to Cart"
                        });
                    }
                })
            }
        }
    })

});

app.get('/cart/:userId', function (req, res) {
    if (!req.params.userId) {
        return res.status(400).json({
            message: "UserId not valid"
        })
    }
    var userId = req.params.userId;

    cartModel.find({
        userId: new ObjectID(userId)
    }, function (error, response) {
        if (error) {
            console.log('Error:   ', response)
            return res.status(201).json("Error Finding");
        }
        if (response) {
            if (response.length > 0) {

                return res.status(200).json({
                    status: 200,
                    cart: response
                })
            }
            else {
                return res.json({
                    status: 200,
                    message: "Cart is Empty"
                });
            }
        }
    })


});

app.post('/remove', function (req, res) {
    var userId = req.body.userId;
    var itemId = req.body.itemId;
    var quantity = 1;

    cartModel.find({
        userId: new ObjectID(userId),
        menuItemId: itemId
    }, function (error, response) {
        if (error) {
            console.log('Error:   ', response)
            return res.status(201).json("Error Finding");
        }
        if (response) {
            if (response.length > 0) {
                if (response.quantity > 1) {
                    let updatedQuantity = response.quantity - quantity;
                    updateQuery = {
                        $set: {
                            quantity: updatedQuantity
                        }
                    }

                    cartModel.findByIdAndUpdate({
                        _id: response._id
                    }, updateQuery, function (err, data) {
                        if (err) {
                            console.log("Error was Occurred", err)
                            return res.status(400).json({
                                message: "Error was Occurred"
                            })
                        }
                        if (data) {
                            return res.status(200).json({
                                status: 200,
                                message: "Removed from Cart"
                            })
                        }
                    })
                }
                else {
                    cartModel.remove({
                        _id: response._id
                    }, function (error, response) {
                        if (error) {
                            console.log('Error:   ', response)
                            return res.status(201).json("Error Adding");
                        }
                        if (response) {
                            return res.json({
                                status: 200,
                                message: "Removed from Cart"
                            });
                        }
                    })
                }
            }
        }
    })

});

app.post('/create-order', function (req, res) {
    var userId = req.body.userId;
    var itemIdArray = req.body.items;
    var totalAmount = req.body.totalAmount;
    var timestamp = new Date().getTime();
    var newOrderId = 'OD' + timestamp;
    
    loginModel.find({ _id: userId }).exec(function (err, user) {
        if (err) {
            return res.json({
                status: 401,
                msg: "something went wrong"
            })
        }
        console.log(user);
        if (user.length > 0) {
            console.log("user",user);
            orderModel.create({
                userId: new ObjectID(userId),
                ItemArray: itemIdArray,
                amount: totalAmount,
                orderId: newOrderId
            }, function (error, response) {
                if (error) {
                    console.log('Error:   ', response)
                    return res.status(201).json("Error Adding");
                }
                if (response) {
                    const data = {
                        from: 'Pizza Order <royajit51@gmail.com>',
                        to: user[0].email,
                        subject: 'Order Receipt',
                        text: 'Testing some Mailgun awesomness!'
                    };
                    mg.messages().send(data, function (error, body) {
                        if(error) {
                            console.log('Error:   ', error)
                    return res.status(201).json("Error Sending Mail");
                        }
                        console.log(body);
                        if(body) {
                            return res.json({
                                status: 200,
                                message: "Ordered Successfully"
                            });
                        }
                    });
                }
            })
        
        }
        else {
            return res.json({
                status: 400,
                message: "User not found"
            });
        }
    });


});


module.exports = app;
